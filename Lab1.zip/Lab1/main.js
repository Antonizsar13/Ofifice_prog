function drawPicter(picters,region)
{
    let canvas = document.getElementById(region);
    let ctx = canvas.getContext('2d');
    let img = new Image();
    img.src = picters;
    img.onload = function(){
        ctx.drawImage(img, 0, 0, 300, 150)
    }
}

function clearImage(region)
{
    let canvas = document.getElementById(region);
    let ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 300, 150);
}

const amoutOfTeapots = 4;
function teapotsON(){   
    for (var i = 1; i <= amoutOfTeapots; i++)
    drawPicter("tehno/tehno_" + i + ".jpg", "teapotshow" + i);

    
    document.getElementById('textTeapotsON').hidden = false;
    document.getElementById('textTeapotsOFF').hidden = true;
}

function teapotsOFF(){
    for (var i = 1; i <= amoutOfTeapots; i++)
    clearImage( "teapotshow" + i);
    document.getElementById('textTeapotsON').hidden = true;
    document.getElementById('textTeapotsOFF').hidden = false;
}